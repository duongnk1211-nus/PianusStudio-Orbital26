import { useEffect } from "react";
import { Notes } from "../components/Notes.jsx";
import { keyMaps } from "../components/keyMaps.jsx";

export function useKeyboard(bindingOption, symMap, synthRef, barsRef, sideEffect) {
  useEffect(() => {
    for (const note of Notes) {
      note.key = " ";
    }
    const option = bindingOption ?? 1;
    const keyMap = new Map(Object.entries(keyMaps[option]));
    const noteMap = new Map();
    for (const [sym, key] of keyMap) {
      if (key !== " "){
        noteMap.set(key, symMap.get(sym));
        symMap.get(sym).key = key;
      }
    }

    const handleKeyDown = async (e) => {
      if (e.key === " ") return;
      const note = noteMap.get(e.key);
      if (note) {
        e.preventDefault();
        if (e.repeat) return;
        await note.attack(synthRef, barsRef, sideEffect)();
      }
    };
    const handleKeyUp = async (e) => {
      if (e.key === " ") return;
      const note = noteMap.get(e.key);
      if (note) {
        e.preventDefault();
        await note.release(synthRef, barsRef, sideEffect)();
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    }
  }, [bindingOption]);
}