import { useState } from "react";
import { supabase } from "../components/supabaseClient";
import { Link } from "react-router-dom";
import "../styles/LoginSignup.css";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);

  const isMatch = password === confirmPassword;

  const hasSpace = /\s/.test(username);

  const handleSignup = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signUp({ email, password });
    setMessage(error ? "Error: " + error.message : "Sign‑up successful! Check your email & Sign in using your new credentials!");
    setLoading(false);
  }

  return (
    <div className="signup-page" id="signup-page">
      <div className="signup-container">
        <div className="go-back">
          &larr; {" "}
          <Link to="/" style={{ color: "#030303e7" }}>
            {"Back to Home"}
          </Link>
        </div>
        <h2>Registration</h2>
        <h3>Please sign up to continue!</h3>
        <div style={{ marginBottom: "40px" }}>
          <input
            id="signup-email"
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            style={{ width: "95%", marginBottom: "1rem" }}
          />
          <input
            id="signup-username"
            type="username"
            placeholder="Username"
            value={username}
            onChange={e => setUsername(e.target.value)}
            style={{ width: "95%", marginBottom: "1rem" }}
          />
          <input
            id="signup-password"
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            style={{ width: "95%", marginBottom: "1rem" }}
          />
          <input
            id="signup-confirm-password"
            type="password"
            placeholder="Retype Password"
            value={confirmPassword}
            onChange={e => setConfirmPassword(e.target.value)}
            style={{ width: "95%", marginBottom: "1rem" }}
          />
          <p style={{
            color: isMatch && !hasSpace ? "green" : "red",
            fontSize: "0.9rem",
            fontWeight: "bold",
          }}>
          { hasSpace 
            ? "Username cannot have space ❌"
            : (confirmPassword.length > 0
            ? isMatch
            ? "Passwords match ✅"
            : "Passwords do not match ❌"
            : "")}
          </p>
        </div>
        <button onClick={handleSignup} disabled={loading} style={{ borderRadius: "10px" }}>
          {loading ? "Processing..." : "Sign Up"}
        </button>
        <p style={{ marginTop: "10px", cursor: "pointer", color: "#1a1717" }}>
          Already have an account? <Link to="/login" style={{ color: "#1a17179f" }}>Log in</Link>
        </p>
        {message && <p style={{ color: message.includes("successful") ? "green" : "red" }}>{message}</p>}
      </div>
    </div >
  );
}